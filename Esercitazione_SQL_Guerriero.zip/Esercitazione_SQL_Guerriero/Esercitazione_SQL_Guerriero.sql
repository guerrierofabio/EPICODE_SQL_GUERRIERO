Create table Product (
ProductID INT Primary Key,
NameProduct Varchar(150),
Category Varchar(150)
);

drop table Product;

Create DATABASE ToysGroup;

use ToysGroup;

-- Creazione tabella per Prodotti

Create table Product 
(
ProductID INT Primary Key,
NameProduct Varchar(150),
Category Varchar(150)
);

-- Creazione tabella per Regioni del Mondo 

Create table Region 
(
RegionID INT Primary Key,
NameRegion Varchar(150),
State Varchar(150)
);

-- Creazione tabella delle Transazioni 
CREATE TABLE Sales 
(
    SalesID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    Amount DECIMAL(10, 2),
    SaleDate DATE,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Popolamento tabella Product 

INSERT INTO Product (ProductID, NameProduct, Category)
VALUES
    (1, 'CicciobelloTanteCoccole', 'Toys'),
    (2, 'BarbieCamperDeiSogni', 'Toys'),
    (3, 'Jenga', 'Games'),
    (4, 'Dama', 'Games'),
    (5, 'Uno', 'Games'),
    (6, 'Puzzle', 'Games'),
    (7, 'BubbleGun', 'Games'),
    (8, 'Trampoline', 'Games'),
    (9, "WoodPuzzle", "Games"),
    (10, 'MyFirstLaptop', 'Games'),
    (11, 'LittleBarbie', 'Games');
    
    Select *
    From product;
    
-- Popolamento tabella Region

    INSERT INTO Region (RegionID, NameRegion, State)
VALUES
    (1, 'NewYork', 'USA'),
    (2, 'Berlin', 'Germany'),
    (3, 'Beijing', 'China'),
    (4, 'Gdansk', 'Poland'),
    (5, 'Montpellier', 'France'),
    (6, 'Valona', 'Albania'),
    (7, 'Avellino', 'Italy'),
    (8, 'Girona', 'Spain'),
    (9, 'Lisbon', 'Portugal'),
    (10, 'AddisAbeba', 'Ethiopia'),
    (11, 'Adelaide', 'Australia');
    
    select *
    from Region;
    
    -- Popolamento tabella Sales
    
    INSERT INTO Sales (SalesID, ProductID, RegionID, Amount, SaleDate)
VALUES
    (1, 1, 4, 82.50, '2024-01-15'),
    (2, 2, 2, 98.00, '2024-02-20'),
    (3, 4, 11, 15.75, '2024-03-10'),
    (4, 3, 3, 40.50, '2024-04-05'),
	(5, 7, 1, 18.50, '2023-08-30'),
    (6, 5, 2, 42.00, '2023-09-05'),
    (7, 6, 1, 27.80, '2023-10-10'),
    (8, 11, 3, 33.25, '2023-11-15'),
    (9, 9, 1, 38.50, '2023-12-20'),
    (10, 8, 2, 29.75, '2024-01-25'),
    (11, 10, 3, 25.00, '2024-02-29');
    
    /* (1, 'CicciobelloTanteCoccole', 'Toys'),
    (2, 'BarbieCamperDeiSogni', 'Toys'),
    (3, 'Jenga', 'Games'),
    (4, 'Dama', 'Games'),
    (5, 'Uno', 'Games'),
    (6, 'Puzzle', 'Games'),
    (7, 'BubbleGun', 'Games'),
    (8, 'Trampoline', 'Games'),
    (9, "WoodPuzzle", "Games"),
    (10, 'MyFirstLaptop', 'Games'),
    (11, 'LittleBarbie', 'Games');*/
    
    select *
    from sales;
    
    -- Verifica univocità delle PK
    
    SELECT 
    COUNT(ProductID) AS Count_ProductID, 
    COUNT(DISTINCT ProductID) AS Count_Distinct_ProductID 
    FROM Sales;
    
    -- Elenco Prodotti venduti e fatturato annuo totale
    
SELECT 
P.NameProduct, 
YEAR(SaleDate) AS YearSales, 
SUM(Amount) AS TotalAmount
FROM Product AS P
INNER JOIN Sales AS S
ON P.ProductID = S.ProductID
GROUP BY P.NameProduct,
YEAR(SaleDate);

-- Fatturato totale per stato per anno ordinato per data e fatturato decrescente
SELECT 
R.State, 
YEAR(SaleDate) AS YearSales, 
SUM(Amount) AS TotalAmount
FROM Region as R
INNER JOIN Sales as S 
ON R.RegionID = S.RegionID
GROUP BY R.State, YEAR(SaleDate)
ORDER BY YEAR(SaleDate), TotalAmount DESC;

-- Categoria di articoli maggiormente richiesta dal mercato

SELECT P.Category, 
COUNT(*) AS TotalSales
FROM Product AS P
JOIN Sales AS S
ON P.ProductID = S.ProductID
GROUP BY P.Category
ORDER BY TotalSales DESC
LIMIT 1;

-- Categoria maggiormente richiesta: Games
    
 -- Prodotti invenduti (modo 1)
 
 SELECT ProductID, NameProduct
FROM Product
WHERE ProductID NOT IN 
(SELECT DISTINCT ProductID FROM Sales);
    
-- Prodotti invenduti (modo 2)

SELECT P.ProductID, P.NameProduct
FROM Product AS P
LEFT JOIN Sales AS S 
ON P.ProductID = S.ProductID
WHERE S.SalesID IS NULL;

-- Non vi sono prodotti invenduti 

-- Elenco dei prodotti con la rispettiva ultima data di vendita

SELECT P.NameProduct, 
MAX(SaleDate) AS LastSaleDate
FROM Product AS P
LEFT JOIN Sales AS S
ON P.ProductID = S.ProductID
GROUP BY P.NameProduct;